namespace Barcoder.Qr
{
    public enum Encoding
    {
        Auto,
        Numeric,
        AlphaNumeric,
        Unicode
    }
}
