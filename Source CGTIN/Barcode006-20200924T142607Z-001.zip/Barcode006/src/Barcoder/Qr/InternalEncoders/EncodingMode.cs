namespace Barcoder.Qr.InternalEncoders
{
    internal enum EncodingMode
    {
        Numeric = 1,
        AlphaNumeric = 2,
        Byte = 4,
        Kanji = 8
    }
}
