﻿namespace Barcoder.Aztec
{
    internal enum EncodingMode
    {
        Upper,
        Lower,
        Digit,
        Mixed,
        Punct
    }
}
