﻿namespace Barcoder.Renderer.Image
{
    public enum ImageFormat
    {
        Bmp,
        Gif,
        Jpeg,
        Png,
    }
}
