﻿using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("Barcoder.Tests")]
